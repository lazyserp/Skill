from flask import Blueprint

main_bp = Blueprint('main', __name__)

# 👇 This MUST come after main_bp is defined to avoid circular import
def register_main_routes():
    from app.main import routes  # delayed import
