from flask import Flask
from app.extensions import db
from app.routes import login_manager, home, dashboard, register, login, logout, load_user  # functions from routes
import os

template_path = os.path.join(os.path.dirname(__file__), 'app', 'templates')
app = Flask(__name__, template_folder=template_path)
app.config.from_object('app.config.Config')

db.init_app(app)
login_manager.init_app(app)

if __name__ == "__main__":
    app.run(debug=True)
